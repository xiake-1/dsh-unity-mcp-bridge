/*
+------------------------------------------------------------------+
|  Author: Ivan Murzak (https://github.com/IvanMurzak)             |
|  Repository: GitHub (https://github.com/IvanMurzak/Unity-MCP)    |
|  Copyright (c) 2025 Ivan Murzak                                  |
|  Licensed under the Apache License, Version 2.0.                 |
|  See the LICENSE file in the project root for more information.   |
+------------------------------------------------------------------+
*/

#nullable enable

namespace com.IvanMurzak.Unity.MCP.Editor.DependencyResolver
{
    /// <summary>
    /// Configuration for the NuGet dependency resolver.
    /// Contains the list of required NuGet packages and path settings.
    /// </summary>
    static class NuGetConfig
    {
        /// <summary>Log tag shared across all DependencyResolver classes.</summary>
        public const string LogTag = "[NuGet]";

        /// <summary>
        /// Scripting define added to all build target groups once the resolver
        /// confirms the NuGet DLLs are in place. Main plugin asmdefs are gated
        /// on this define so they only attempt to compile when the references
        /// are guaranteed to resolve.
        /// </summary>
        public const string ReadyDefine = "UNITY_MCP_READY";

        /// <summary>
        /// Prefix of the dependency-generation gate define. Every define starting with this
        /// prefix other than <see cref="DependencyGenerationDefine"/> is stale and gets stripped
        /// by <see cref="RecompileGate.EnsureReadyDefine"/>.
        /// </summary>
        public const string DependencyGenerationDefinePrefix = "UNITY_MCP_DEPS_";

        /// <summary>
        /// Generation marker for the pinned NuGet set in <see cref="Packages"/>, and the SECOND
        /// gate the main plugin asmdefs are constrained on (Unity ANDs defineConstraints).
        ///
        /// <para><b>Bump this whenever any version in <see cref="Packages"/> changes.</b> A CI check
        /// (<c>.github/scripts/check_nuget_gate.py</c>) fails the build if you don't.</para>
        ///
        /// <para>Why it exists (Unity-MCP#957). <see cref="ReadyDefine"/> alone is a boolean "the
        /// resolver has run at some point" flag that lives in ProjectSettings and therefore SURVIVES
        /// a package upgrade. It records that <i>some</i> DLL set was restored — not <i>which</i>.
        /// When a package upgrade raises a NuGet pin, the sequence was:</para>
        /// <list type="number">
        ///   <item>UPM writes the new package files; the PREVIOUS AppDomain is still alive.</item>
        ///   <item>Its <see cref="NuGetDependencyResolver.OnRegisteredPackages"/> handler evaluates
        ///   the <b>OLD</b> package's compiled <see cref="Packages"/> array, so
        ///   <see cref="NuGetPackageRestorer.AllPackagesInstalled"/> reports true and no restore runs
        ///   — the outgoing package cannot know about a pin the incoming package raised.</item>
        ///   <item><see cref="ReadyDefine"/> is still set, so the gate is OPEN and Unity compiles the
        ///   NEW sources against the OLD DLLs → CS0246 on every newly-referenced type.</item>
        ///   <item>The failed compile blocks the domain reload, so the NEW resolver never runs and can
        ///   never repair the DLL set. Reopening the project lands in Safe Mode. Deadlock.</item>
        /// </list>
        /// <para>A package whose code has not run yet can only signal Unity through static asmdef
        /// data, so the gate must be part of that data. Because this define is bumped in lockstep with
        /// the pins, an install restored for an older generation can never satisfy the new
        /// constraint: the main assemblies are simply skipped, the compile SUCCEEDS, the domain
        /// reloads, and the new resolver restores the correct DLLs and adds this define — the same
        /// self-healing two-pass path a clean install already takes.</para>
        /// </summary>
        public const string DependencyGenerationDefine = DependencyGenerationDefinePrefix + "17";

        /// <summary>
        /// Every define the main plugin asmdefs are gated on. All of them must be present for the
        /// plugin to compile; <see cref="RecompileGate"/> adds and removes them as a set.
        /// </summary>
        public static readonly string[] GateDefines = { ReadyDefine, DependencyGenerationDefine };

        /// <summary>
        /// NuGet v3 flat container base URL.
        /// Download URL pattern: {base}/{id}/{version}/{id}.{version}.nupkg
        /// </summary>
        public const string NuGetBaseUrl = "https://api.nuget.org/v3-flatcontainer";

        /// <summary>
        /// Where extracted NuGet DLLs are installed (mutable location inside Unity's asset pipeline).
        /// PluginImporter requires files to be under Assets/ to work.
        /// </summary>
        public const string InstallPath = "Assets/Plugins/NuGet";

        /// <summary>
        /// Where downloaded .nupkg files are cached.
        /// Library/ survives domain reloads but is not tracked by git.
        /// </summary>
        public const string CachePath = "Library/NuGetCache";

        /// <summary>
        /// Top-level NuGet package dependencies.
        /// Transitive dependencies are resolved automatically from .nuspec metadata.
        ///
        /// includeInBuild: true  = DLL included in game builds (runtime dependency)
        /// includeInBuild: false = editor-only DLL (excluded from builds)
        /// </summary>
        public static readonly NuGetPackage[] Packages =
        {
            // --- Runtime dependencies (included in game builds) ---
            // v8 pinned to match what McpPlugin.dll (netstandard2.1) is compiled against.
            // Higher versions cause MissingMethodException at runtime in Unity versions
            // whose built-in BCL doesn't override our NuGet install (e.g. Unity 6.5).
            // 6.1.0 drops the unused ModelContextProtocol dep; earlier versions drag in a
            // v10 BCL stack via MCP.Core.1.2.0 that collides with our v8 pins in Unity.
            // 6.1.1 bumps the transitive ReflectorNet dependency to 5.1.1.
            // 7.1.0 (mcp-authorize g5/g6) adds the shared ServerLaunchArguments launch-arg builder,
            // the AuthOption.token member + LocalTokenMcpStrategy, and the 3-mode configurator — all
            // consumed by the local self-hosted auth path. McpPlugin.Common 7.1.0 follows transitively.
            // 8.3.0 (oauth-client-error-hygiene a1–a3) adds the dead-family memo + the
            // SignInRequiredReason surface ("server configuration error" class for invalid_target),
            // and the ConnectionCredentialCoordinator stop-on-dead-credential / resume-on-SignedIn-edge
            // behavior the AssistedReauthService (02 §C4, D4 ladder) renders and relies on.
            // 8.9.0 adds the shared Custom+oauth loopback rule (CustomOAuthCredentialPolicy / HostScope)
            // and the consumer-supplied ConnectionConfig.ConnectionErrorHint, both used by UnityConnectionConfig.
            // 8.11.0 sends a tool call to the plugin once (no re-send per plugin-timeout), adds the
            // server's `tool-timeout` arg (Consts.MCP.Server.Args/Env.ToolTimeout, DefaultToolTimeoutMs)
            // that McpServerManager passes, and the plugin-side duplicate-request guard.
            new NuGetPackage("com.IvanMurzak.McpPlugin",                             "8.13.1", includeInBuild: true),
            // Pinned explicitly so the resolver doesn't drift below the version
            // bundled in this package. The atomic API surface (TryModifyAt,
            // TryPatch, TryReadAt, View, Grep) introduced in 5.1.0 is exercised
            // by the EditMode tests under Tests/Editor/AtomicApi/, which
            // compile-fail against 5.0.0. 5.1.1 adds defensive try/catch around
            // reflection so the documented no-throw contract on Try* methods holds.
            // 5.5.0 (McpPlugin 8.11.1 depends on it) makes ReflectorNet's default MainThread recognize the
            // main thread by its SynchronizationContext, not managed thread id 1. The plugin replaces
            // MainThread.Instance with UnityMainThread (MainThreadDispatcher.MainThreadId), so Unity's
            // main-thread detection, including Unity 7 CoreCLR's id-2 main thread, does not rely on it.
            new NuGetPackage("com.IvanMurzak.ReflectorNet",                           "5.5.0",  includeInBuild: true),
            new NuGetPackage("System.Text.Json",                                      "8.0.5",  includeInBuild: true),
            new NuGetPackage("Microsoft.AspNetCore.SignalR.Client",                   "8.0.15", includeInBuild: true),
            new NuGetPackage("Microsoft.AspNetCore.SignalR.Protocols.Json",           "8.0.15", includeInBuild: true),
            new NuGetPackage("Microsoft.Extensions.Logging",                          "8.0.1",  includeInBuild: true),
            // Pinned to 8.0.3 to match the transitive requirement from
            // Microsoft.AspNetCore.Http.Connections.Client 8.0.15 (pulled in via
            // SignalR.Client 8.0.15 → SignalR.Client.Core 8.0.15). Any lower pin
            // (e.g. 8.0.2) produces an infinite restore loop on every domain reload:
            // higher-version-wins extracts 8.0.3 to disk while AllPackagesInstalled()
            // keeps checking for the pinned dir, never finds it, and triggers Restore()
            // again on the next reload. See Unity-MCP#677.
            new NuGetPackage("Microsoft.Extensions.Logging.Abstractions",             "8.0.3",  includeInBuild: true),
            new NuGetPackage("Microsoft.Extensions.DependencyInjection",              "8.0.1",  includeInBuild: true),
            new NuGetPackage("Microsoft.Extensions.DependencyInjection.Abstractions", "8.0.2",  includeInBuild: true),
            new NuGetPackage("Microsoft.Extensions.Options",                          "8.0.2",  includeInBuild: true),
            new NuGetPackage("Microsoft.Extensions.Caching.Abstractions",             "8.0.0",  includeInBuild: true),
            new NuGetPackage("Microsoft.Extensions.Hosting.Abstractions",             "8.0.1",  includeInBuild: true),
            new NuGetPackage("R3",                                                    "1.3.0",  includeInBuild: true),

            // --- Editor-only dependencies (excluded from builds) ---
            // RQL (the query language of rql-query / rql-mutate and the tools' data layer): Editor-only, so it never
            // reaches player builds. Its only dependency is System.Text.Json 8.0.5, the version pinned above.
            new NuGetPackage("com.IvanMurzak.Rql",                                    "0.1.1"),
            new NuGetPackage("Microsoft.Bcl.Memory",                                  "10.0.3"),
            // Pinned to 4.8.0 so transitive System.Collections.Immutable stays at 7.0.0
            // (forward-compatible with Unity 6.6's built-in 8.0.0). Roslyn 4.14 requires
            // SCI 9.0.0 which clashes with Unity's built-in.
            new NuGetPackage("Microsoft.CodeAnalysis.CSharp",                         "4.8.0"),
        };

        /// <summary>
        /// Package IDs to exclude from transitive dependency resolution. Matched
        /// case-insensitively against the NuGet package ID (not the DLL filename).
        ///
        /// When a package ID appears here:
        ///   - the resolver skips it (and its transitive deps) during Install()
        ///   - RemoveUnnecessaryPackages() deletes its install directory if present
        ///   - AllPackagesInstalled() forces a full restore while it's still on disk
        ///
        /// Use this when a top-level package's nuspec pulls in a transitive dep that
        /// is unused by your project's source AND whose own dependency chain conflicts
        /// with your pinned versions (e.g., a netstandard2.0 package targeting a newer
        /// BCL than Unity's runtime provides).
        /// </summary>
        public static readonly string[] SkipPackages = { };

        /// <summary>
        /// Target framework priority for selecting DLLs from .nupkg lib/ folders.
        /// First match wins. Ordered by preference for Unity compatibility.
        /// </summary>
        public static readonly string[] TargetFrameworkPriority =
        {
            "netstandard2.1",
            "netstandard2.0",
            "net48",
            "net472",
            "net471",
            "net47",
            "net462",
            "net461",
            "net46",
            "net45",
            "netstandard1.3",
            "netstandard1.1",
            "netstandard1.0",
            "",  // fallback: root lib/ folder
        };
    }
}
