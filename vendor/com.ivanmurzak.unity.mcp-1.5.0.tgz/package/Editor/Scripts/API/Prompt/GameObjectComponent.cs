/*
┌──────────────────────────────────────────────────────────────────┐
│  Author: Ivan Murzak (https://github.com/IvanMurzak)             │
│  Repository: GitHub (https://github.com/IvanMurzak/Unity-MCP)    │
│  Copyright (c) 2025 Ivan Murzak                                  │
│  Licensed under the Apache License, Version 2.0.                 │
│  See the LICENSE file in the project root for more information.  │
└──────────────────────────────────────────────────────────────────┘
*/

#nullable enable
using System.ComponentModel;
using com.IvanMurzak.McpPlugin;
using com.IvanMurzak.McpPlugin.Common.Model;

namespace com.IvanMurzak.Unity.MCP.Editor.API
{
    [AiPromptType]
    public partial class Prompt_GameObjectComponent
    {
        [AiPrompt(Name = "add-standard-components", Role = Role.User, Enabled = false)]
        [Description("Add common Unity components like Rigidbody, Collider, and Renderer to selected GameObjects.")]
        public string AddStandardComponents()
        {
            return "Add standard Unity components to selected GameObjects: MeshRenderer, MeshFilter, Collider, and Rigidbody as appropriate for the object type.";
        }

        [AiPrompt(Name = "setup-player-controller", Role = Role.User, Enabled = false)]
        [Description("Create a basic player controller with movement scripts and necessary components.")]
        public string SetupPlayerController()
        {
            return "Create player GameObject with CharacterController or Rigidbody, add basic movement script with WASD controls, camera follow, and jump mechanics.";
        }

        [AiPrompt(Name = "create-ui-canvas", Role = Role.User, Enabled = false)]
        [Description("Setup Canvas with common UI elements and proper scaling configuration.")]
        public string CreateUICanvas()
        {
            return "Create UI Canvas with Canvas Scaler set to Scale With Screen Size, add EventSystem, and create common UI elements like buttons, text, and panels.";
        }

        [AiPrompt(Name = "add-physics-interactions", Role = Role.User, Enabled = false)]
        [Description("Configure colliders, rigidbodies, and physics materials for realistic physics interactions.")]
        public string AddPhysicsInteractions()
        {
            return "Setup physics interactions by adding appropriate Colliders, configure Rigidbody properties, create Physics Materials, and setup collision layers.";
        }

        [AiPrompt(Name = "create-interactive-object", Role = Role.User, Enabled = false)]
        [Description("Create an interactive GameObject that responds to player input or triggers.")]
        public string CreateInteractiveObject()
        {
            return "Create interactive GameObject with appropriate collider setup, add interaction script with OnTriggerEnter/OnCollisionEnter events, and visual feedback.";
        }

        [AiPrompt(Name = "setup-audio-source", Role = Role.User, Enabled = false)]
        [Description("Add and configure AudioSource component with common settings.")]
        public string SetupAudioSource()
        {
            return "Add AudioSource component to selected GameObjects, configure 3D spatial settings, volume, pitch, and loop options as appropriate.";
        }

        [AiPrompt(Name = "create-particle-effects", Role = Role.User, Enabled = false)]
        [Description("Add particle systems for visual effects like explosions, fire, or magic.")]
        public string CreateParticleEffects()
        {
            return "Create GameObject with Particle System component, configure emission, shape, velocity, and rendering settings for common visual effects.";
        }

        [AiPrompt(Name = "setup-animator-component", Role = Role.User, Enabled = false)]
        [Description("Add Animator component and basic animation setup to GameObjects.")]
        public string SetupAnimatorComponent()
        {
            return "Add Animator component to selected GameObjects, create basic Animator Controller, and setup simple animation states for common actions.";
        }
    }
}