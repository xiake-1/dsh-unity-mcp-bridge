﻿/*
┌──────────────────────────────────────────────────────────────────┐
│  Author: Ivan Murzak (https://github.com/IvanMurzak)             │
│  Repository: GitHub (https://github.com/IvanMurzak/Unity-MCP)    │
│  Copyright (c) 2025 Ivan Murzak                                  │
│  Licensed under the Apache License, Version 2.0.                 │
│  See the LICENSE file in the project root for more information.  │
└──────────────────────────────────────────────────────────────────┘
*/

#nullable enable
using Extensions.Unity.PlayerPrefsEx;
using UnityEditor;

namespace com.IvanMurzak.Unity.MCP.Editor.UI
{
    [InitializeOnLoad]
    static class MainWindowInitializer
    {
        static PlayerPrefsBool isInitialized = new PlayerPrefsBool("Unity-MCP.MainWindow.Initialized");

        static MainWindowInitializer()
        {
            // An asset import worker shares these prefs but has no window to open; opening it would connect (#1050).
            if (AssetDatabase.IsAssetImportWorkerProcess() || isInitialized.Value)
                return;

            EditorApplication.update += PerformInitialization;
        }

        static void PerformInitialization()
        {
            EditorApplication.update -= PerformInitialization;

            if (isInitialized.Value)
                return;

            // Perform initialization
            UnityMcpPluginEditor.InitSingletonIfNeeded();
            MainWindowEditor.ShowWindow();

            isInitialized.Value = true;
        }
    }
}