/*
┌──────────────────────────────────────────────────────────────────┐
│  Author: Ivan Murzak (https://github.com/IvanMurzak)             │
│  Repository: GitHub (https://github.com/IvanMurzak/Unity-MCP)    │
│  Copyright (c) 2025 Ivan Murzak                                  │
│  Licensed under the Apache License, Version 2.0.                 │
│  See the LICENSE file in the project root for more information.  │
└──────────────────────────────────────────────────────────────────┘
*/

#nullable enable
#if UNITY_6000_5_OR_NEWER
using System.Collections.Generic;
using System.Linq;
using System.Text;
using com.IvanMurzak.ReflectorNet;
using com.IvanMurzak.ReflectorNet.Utils;
using AIGD;
using UnityEngine;

namespace com.IvanMurzak.Unity.MCP.Runtime.Utils
{
    public static partial class GameObjectUtils
    {
        public static UnityEngine.GameObject? FindBy(GameObjectRef? gameObjectRef, out string? error)
        {
            if (gameObjectRef == null)
            {
                error = $"{nameof(gameObjectRef)} is null.";
                return null;
            }
            if (!gameObjectRef.IsValid(out var validationError))
            {
                error = validationError;
                return null;
            }
            return FindBy(
                entityId: gameObjectRef.InstanceID,
                path: gameObjectRef.Path,
                name: gameObjectRef.Name,
                error: out error);
        }

        public static GameObject? FindBy(EntityId entityId, string? path, string? name, out string? error)
        {
            path = StringUtils.TrimPath(path);
            var go = default(GameObject);

            // Find by 'instanceID' (int). Priority: 1. (Recommended)
            if (entityId != EntityId.None)
            {
                go = FindByInstanceID(entityId);
                if (go == null)
                {
                    error = $"Not found GameObject with instanceID '{entityId}'";
                    return null;
                }
            }
            // Find by 'path'. Priority: 2.
            else if (!string.IsNullOrEmpty(path))
            {
                go = FindByPath(path);
                if (go == null)
                {
                    error = $"Not found GameObject at path '{path}'";
                    return null;
                }
            }
            // Find by 'name'. Priority: 3.
            else if (!string.IsNullOrEmpty(name))
            {
                go = FindByName(name);
                if (go == null)
                {
                    error = $"Not found GameObject with name '{name}'";
                    return null;
                }
            }
            // No valid arguments provided
            else
            {
                error = "No valid arguments provided to find GameObject.";
                return null;
            }
            error = null;
            return go;
        }

        public static GameObject? FindByPath(string? path, GameObject? root = null)
        {
            path = StringUtils.TrimPath(path);

            if (string.IsNullOrEmpty(path))
                return null;

            // If root is null, search in the active scene's root GameObjects
            if (root == null)
            {
                var rootGos = FindRootGameObjects();
                var pathParts = path.Split('/');

                root = rootGos.FirstOrDefault(go => go.name == pathParts[0]);
                if (root == null)
                    return null;

                var currentGameObject = root;

                foreach (var part in pathParts.Skip(1))
                {
                    if (currentGameObject == null)
                        return null;

                    currentGameObject = FindChildByName(currentGameObject, part);
                }

                return currentGameObject;
            }
            else
            {
                var pathParts = path.Split('/');
                var currentGameObject = root;

                foreach (var part in pathParts)
                {
                    if (currentGameObject == null)
                        return null;

                    currentGameObject = FindChildByName(currentGameObject, part);
                }

                return currentGameObject;
            }
        }

        public static GameObject? FindByName(string? name, GameObject? root = null)
        {
            if (string.IsNullOrEmpty(name))
                return null;

            // If root is null, search in the active scene's root GameObjects
            if (root == null)
            {
                var rootGos = FindRootGameObjects();
                if (rootGos == null)
                    return null;

                foreach (var rootGo in rootGos)
                {
                    // Check if root matches
                    if (rootGo.name == name)
                        return rootGo;

                    // Search recursively in children
                    var found = FindByNameRecursive(rootGo, name);
                    if (found != null)
                        return found;
                }

                return null;
            }
            else
            {
                // Check if root matches
                if (root.name == name)
                    return root;

                // Search recursively in children
                return FindByNameRecursive(root, name);
            }
        }

        private static GameObject? FindByNameRecursive(GameObject parent, string name)
        {
            foreach (Transform child in parent.transform)
            {
                if (child.name == name)
                    return child.gameObject;

                var found = FindByNameRecursive(child.gameObject, name);
                if (found != null)
                    return found;
            }

            return null;
        }
        public static GameObject? FindChildByName(this GameObject parent, string name)
        {
            if (parent == null || string.IsNullOrEmpty(name))
                return null;

            foreach (Transform child in parent.transform)
            {
                if (child.name == name)
                    return child.gameObject;
            }

            return null;
        }
        public static GameObject? AddChild(this GameObject parent, string name)
        {
            if (parent == null || string.IsNullOrEmpty(name))
                return null;

            return parent.AddChild(new GameObject(name));
        }
        public static GameObject? AddChild(this GameObject parent, GameObject child)
        {
            if (parent == null || child == null)
                return null;

            child.transform.SetParent(parent.transform, false);
            return child;
        }

        public static string? GetPath(this GameObject? go)
        {
            if (go == null)
                return null;

            var path = new StringBuilder(go.name);
            var currentTransform = go.transform.parent;

            while (currentTransform != null)
            {
                path.Insert(0, '/'); // Prepend '/' to the start
                path.Insert(0, currentTransform.name); // Prepend the name to the start
                currentTransform = currentTransform.parent;
            }

            return path.ToString();
        }
    }
}
#endif
