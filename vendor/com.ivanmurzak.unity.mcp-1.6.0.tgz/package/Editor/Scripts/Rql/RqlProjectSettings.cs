/*
┌──────────────────────────────────────────────────────────────────┐
│  Author: Ivan Murzak (https://github.com/IvanMurzak)             │
│  Repository: GitHub (https://github.com/IvanMurzak/Unity-MCP)    │
│  Copyright (c) 2026 Ivan Murzak                                  │
│  Licensed under the Apache License, Version 2.0.                 │
│  See the LICENSE file in the project root for more information.  │
└──────────────────────────────────────────────────────────────────┘
*/

#nullable enable
using System;
using System.Collections.Generic;
using System.Linq;
using Rql;
using UnityEditor;
using UnityEngine;
using static com.IvanMurzak.Unity.MCP.Editor.Rql.RqlValueGuard;
using Object = UnityEngine.Object;

namespace com.IvanMurzak.Unity.MCP.Editor.Rql
{
    /// <summary>
    /// The <c>settings</c> source: Project Settings pages as view objects, e.g. <c>settings | select time.fixedDeltaTime</c>,
    /// <c>settings | set physics.gravity = "(0, -12, 0)"</c>. Each page is an <see cref="IRqlUndoOwners"/> naming its
    /// ProjectSettings/*.asset object: a write is recorded for Undo, dirtied and saved with the assets, like an edit in the
    /// Project Settings window. Pages of optional engine modules (physics) are added by their RQL module's adapter.
    /// </summary>
    [RqlDescription("Project Settings pages (time, quality, player, build; physics with the Physics module): writable, undoable, saved to ProjectSettings/")]
    public sealed class RqlProjectSettings
    {
        public static readonly RqlProjectSettings Instance = new RqlProjectSettings();

        private RqlProjectSettings() { }

        [RqlDescription("Project Settings > Time")]
        public RqlTimeSettings time => RqlTimeSettings.Instance;

        [RqlDescription("Project Settings > Quality (the values of the current level)")]
        public RqlQualitySettings quality => RqlQualitySettings.Instance;

        [RqlDescription("Project Settings > Player")]
        public RqlPlayerSettings player => RqlPlayerSettings.Instance;

        [RqlDescription("Build Settings: the scenes in the build")]
        public RqlBuildSettings build => RqlBuildSettings.Instance;

        public override string ToString() => "project settings";

        /// <summary>
        /// The object stored in <c>ProjectSettings/&lt;file&gt;.asset</c> (e.g. "TimeManager"), the target of the page's Undo
        /// record and dirty flag; an empty list when the Editor has none (a stripped module).
        /// </summary>
        public static IReadOnlyList<Object> Asset(string file)
        {
            var all = AssetDatabase.LoadAllAssetsAtPath($"ProjectSettings/{file}.asset");
            return all.Length > 0 && all[0] != null ? new[] { all[0] } : Array.Empty<Object>();
        }
    }

    [RqlDescription("Project Settings > Time: fixedDeltaTime (physics step), maximumDeltaTime, timeScale, maximumParticleDeltaTime")]
    public sealed class RqlTimeSettings : IRqlUndoOwners
    {
        internal static readonly RqlTimeSettings Instance = new RqlTimeSettings();

        private RqlTimeSettings() { }

        [RqlDescription("Fixed Timestep: seconds between physics / FixedUpdate steps (> 0, e.g. 0.02 = 50 Hz)")]
        public float fixedDeltaTime
        {
            get => Time.fixedDeltaTime;
            set { Require(value, value > 0f, "> 0"); Time.fixedDeltaTime = value; }
        }

        [RqlDescription("Maximum Allowed Timestep: the longest frame physics and FixedUpdate catch up on, seconds (> 0)")]
        public float maximumDeltaTime
        {
            get => Time.maximumDeltaTime;
            set { Require(value, value > 0f, "> 0"); Time.maximumDeltaTime = value; }
        }

        [RqlDescription("Time Scale: speed of game time (1 = real time, 0 = paused; 0 - 100)")]
        public float timeScale
        {
            get => Time.timeScale;
            set { Require(value, value >= 0f && value <= 100f, "between 0 and 100"); Time.timeScale = value; }
        }

        [RqlDescription("Maximum Particle Timestep, seconds (> 0)")]
        public float maximumParticleDeltaTime
        {
            get => Time.maximumParticleDeltaTime;
            set { Require(value, value > 0f, "> 0"); Time.maximumParticleDeltaTime = value; }
        }

        public override string ToString() => $"time (fixedDeltaTime {fixedDeltaTime})";

        IReadOnlyList<Object> IRqlUndoOwners.UndoOwners => RqlProjectSettings.Asset("TimeManager");
    }

    [RqlDescription("Project Settings > Quality: levels, currentLevel and the current level's vSyncCount, antiAliasing, shadows, lodBias …")]
    public sealed class RqlQualitySettings : IRqlUndoOwners
    {
        internal static readonly RqlQualitySettings Instance = new RqlQualitySettings();

        private RqlQualitySettings() { }

        [RqlDescription("the quality level names, by index")]
        public IReadOnlyList<string> levels => QualitySettings.names; // a copy: read-only, so an element write is refused

        [RqlDescription("index of the level the Editor uses (the values below are that level's); assign an index of levels")]
        public int currentLevel
        {
            get => QualitySettings.GetQualityLevel();
            set
            {
                var names = QualitySettings.names;
                Require(value, value >= 0 && value < names.Length, $"a level index 0..{names.Length - 1} ({string.Join(", ", names)})");
                QualitySettings.SetQualityLevel(value, applyExpensiveChanges: true);
            }
        }

        [RqlDescription("V Sync Count: 0 = off, 1 = every V Blank, 2 = every second V Blank")]
        public int vSyncCount
        {
            get => QualitySettings.vSyncCount;
            set { Require(value, value >= 0 && value <= 4, "between 0 and 4"); QualitySettings.vSyncCount = value; }
        }

        [RqlDescription("MSAA samples: 0 (off), 2, 4 or 8")]
        public int antiAliasing
        {
            get => QualitySettings.antiAliasing;
            set { Require(value, value == 0 || value == 2 || value == 4 || value == 8, "0, 2, 4 or 8"); QualitySettings.antiAliasing = value; }
        }

        [RqlDescription("Shadows: Disable, HardOnly or All")]
        public ShadowQuality shadows { get => QualitySettings.shadows; set => QualitySettings.shadows = value; }

        [RqlDescription("Shadow Resolution: Low, Medium, High or VeryHigh")]
        public ShadowResolution shadowResolution { get => QualitySettings.shadowResolution; set => QualitySettings.shadowResolution = value; }

        [RqlDescription("Shadow Distance from the camera, meters (>= 0)")]
        public float shadowDistance
        {
            get => QualitySettings.shadowDistance;
            set { Require(value, value >= 0f, ">= 0"); QualitySettings.shadowDistance = value; }
        }

        [RqlDescription("Shadow Cascades: 1, 2 or 4")]
        public int shadowCascades
        {
            get => QualitySettings.shadowCascades;
            set { Require(value, value == 1 || value == 2 || value == 4, "1, 2 or 4"); QualitySettings.shadowCascades = value; }
        }

        [RqlDescription("Pixel Light Count: per-pixel lights per object in Forward rendering (>= 0)")]
        public int pixelLightCount
        {
            get => QualitySettings.pixelLightCount;
            set { Require(value, value >= 0, ">= 0"); QualitySettings.pixelLightCount = value; }
        }

        [RqlDescription("LOD Bias: > 1 keeps detailed LODs longer (> 0)")]
        public float lodBias
        {
            get => QualitySettings.lodBias;
            set { Require(value, value > 0f, "> 0"); QualitySettings.lodBias = value; }
        }

        [RqlDescription("Maximum LOD Level: LODs below it are never used (>= 0)")]
        public int maximumLODLevel
        {
            get => QualitySettings.maximumLODLevel;
            set { Require(value, value >= 0, ">= 0"); QualitySettings.maximumLODLevel = value; }
        }

        [RqlDescription("Global Mipmap Limit: 0 = full resolution textures, 1 = half, 2 = quarter, 3 = eighth")]
        public int globalTextureMipmapLimit
        {
            get => QualitySettings.globalTextureMipmapLimit;
            set { Require(value, value >= 0 && value <= 3, "between 0 and 3"); QualitySettings.globalTextureMipmapLimit = value; }
        }

        [RqlDescription("Anisotropic Textures: Disable, Enable or ForceEnable")]
        public AnisotropicFiltering anisotropicFiltering { get => QualitySettings.anisotropicFiltering; set => QualitySettings.anisotropicFiltering = value; }

        [RqlDescription("Soft Particles")]
        public bool softParticles { get => QualitySettings.softParticles; set => QualitySettings.softParticles = value; }

        [RqlDescription("Realtime Reflection Probes")]
        public bool realtimeReflectionProbes { get => QualitySettings.realtimeReflectionProbes; set => QualitySettings.realtimeReflectionProbes = value; }

        public override string ToString()
        {
            var (names, level) = (QualitySettings.names, QualitySettings.GetQualityLevel());
            return $"quality ({(level < names.Length ? names[level] : level.ToString())})";
        }

        IReadOnlyList<Object> IRqlUndoOwners.UndoOwners => RqlProjectSettings.Asset("QualitySettings");
    }

    [RqlDescription("Project Settings > Player: companyName, productName, bundleVersion, colorSpace, default screen, runInBackground …")]
    public sealed class RqlPlayerSettings : IRqlUndoOwners
    {
        internal static readonly RqlPlayerSettings Instance = new RqlPlayerSettings();

        private RqlPlayerSettings() { }

        [RqlDescription("Company Name (not empty)")]
        public string companyName
        {
            get => PlayerSettings.companyName;
            set { Require(value, !string.IsNullOrWhiteSpace(value), "a non-empty name"); PlayerSettings.companyName = value; }
        }

        [RqlDescription("Product Name: the application's name (not empty)")]
        public string productName
        {
            get => PlayerSettings.productName;
            set { Require(value, !string.IsNullOrWhiteSpace(value), "a non-empty name"); PlayerSettings.productName = value; }
        }

        [RqlDescription("Version, e.g. \"1.2.0\" (not empty)")]
        public string bundleVersion
        {
            get => PlayerSettings.bundleVersion;
            set { Require(value, !string.IsNullOrWhiteSpace(value), "a non-empty version"); PlayerSettings.bundleVersion = value; }
        }

        // Read-only: switching reimports every texture, which Undo would not reverse (the setting would flip back, the textures not).
        [RqlDescription("Color Space: Gamma or Linear (read-only here: change it in Project Settings > Player, it reimports textures)")]
        public ColorSpace colorSpace => PlayerSettings.colorSpace;

        [RqlDescription("Run In Background: the player keeps running without focus")]
        public bool runInBackground { get => PlayerSettings.runInBackground; set => PlayerSettings.runInBackground = value; }

        [RqlDescription("Fullscreen Mode of standalone players: ExclusiveFullScreen, FullScreenWindow, MaximizedWindow or Windowed")]
        public FullScreenMode fullScreenMode { get => PlayerSettings.fullScreenMode; set => PlayerSettings.fullScreenMode = value; }

        [RqlDescription("Default Screen Width of a windowed standalone player, pixels (> 0)")]
        public int defaultScreenWidth
        {
            get => PlayerSettings.defaultScreenWidth;
            set { Require(value, value > 0, "> 0"); PlayerSettings.defaultScreenWidth = value; }
        }

        [RqlDescription("Default Screen Height of a windowed standalone player, pixels (> 0)")]
        public int defaultScreenHeight
        {
            get => PlayerSettings.defaultScreenHeight;
            set { Require(value, value > 0, "> 0"); PlayerSettings.defaultScreenHeight = value; }
        }

        public override string ToString() => $"player ({productName})";

        IReadOnlyList<Object> IRqlUndoOwners.UndoOwners => RqlProjectSettings.Asset("ProjectSettings");
    }

    [RqlDescription("Build Settings: scenes (the scenes in the build; SceneManager.LoadScene in Play Mode loads only these)")]
    public sealed class RqlBuildSettings : IRqlUndoOwners
    {
        internal static readonly RqlBuildSettings Instance = new RqlBuildSettings();

        private RqlBuildSettings() { }

        [RqlDescription("Scenes In Build: asset paths of the enabled scenes in build-index order; assign the whole list " +
            "(scene assets, each once; listing a disabled scene enables it; the other disabled entries stay, after the enabled ones)")]
        public string[] scenes
        {
            get => EditorBuildSettings.scenes.Where(s => s.enabled).Select(s => s.path).ToArray();
            set
            {
                var current = EditorBuildSettings.scenes;
                var listed = new HashSet<string>(current.Select(s => s.path));
                var paths = new List<string>();
                var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                foreach (var raw in value ?? Array.Empty<string>())
                {
                    // An entry already in the list passes as it is (a deleted scene stays readable and writable back, e.g. on
                    // rollback); a new one must be a scene asset, stored under its canonical project path.
                    var path = raw;
                    if (!listed.Contains(path))
                    {
                        Require(raw, !string.IsNullOrEmpty(raw) && AssetDatabase.GetMainAssetTypeAtPath(raw) == typeof(SceneAsset),
                            "the path of an existing scene asset (\"Assets/…/Level.unity\")");
                        path = AssetDatabase.GUIDToAssetPath(AssetDatabase.AssetPathToGUID(raw));
                    }
                    Require(raw, seen.Add(path), "each scene once");
                    paths.Add(path);
                }
                var disabled = current.Where(s => !s.enabled && !seen.Contains(s.path));
                EditorBuildSettings.scenes = paths.Select(p => new EditorBuildSettingsScene(p, true)).Concat(disabled).ToArray();
            }
        }

        public override string ToString() => $"build ({scenes.Length} scene(s))";

        IReadOnlyList<Object> IRqlUndoOwners.UndoOwners => RqlProjectSettings.Asset("EditorBuildSettings");
    }
}
