/*
┌──────────────────────────────────────────────────────────────────┐
│  Author: Ivan Murzak (https://github.com/IvanMurzak)             │
│  Repository: GitHub (https://github.com/IvanMurzak/Unity-MCP)    │
│  Copyright (c) 2025 Ivan Murzak                                  │
│  Licensed under the Apache License, Version 2.0.                 │
│  See the LICENSE file in the project root for more information.  │
└──────────────────────────────────────────────────────────────────┘
*/

#nullable enable
using System;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;
using com.IvanMurzak.Unity.MCP.Runtime.Utils;
using Microsoft.Extensions.Logging;
using UnityEngine;

namespace com.IvanMurzak.Unity.MCP
{
    public partial class UnityMcpPluginEditor
    {
        public static string ResourcesFileName => "AI-Game-Developer-Config";

        /// <summary>
        /// Project-relative path used by Unity's AssetDatabase API.
        /// Do NOT use this with System.IO File/Directory operations — use <see cref="AssetsFileAbsolutePath"/> instead.
        /// </summary>
        public static string AssetsFilePath => $"UserSettings/{ResourcesFileName}.json";

        /// <summary>
        /// Gets the Unity project root folder path (the folder that contains the Assets directory).
        /// Uses <see cref="Application.dataPath"/> to ensure correctness regardless of the process working directory.
        /// </summary>
        public static string ProjectRootPath => Path.GetDirectoryName(Application.dataPath)!;

        /// <summary>
        /// Absolute path to the config file for use with System.IO File/Directory operations.
        /// Built from <see cref="ProjectRootPath"/> and <see cref="AssetsFilePath"/> to keep paths consistent.
        /// </summary>
        public static string AssetsFileAbsolutePath => Path.GetFullPath(Path.Combine(ProjectRootPath, AssetsFilePath));

        /// <summary>
        /// Absolute path to the skills root folder for use with System.IO File/Directory operations.
        /// If <see cref="SkillsPath"/> is already an absolute path it is returned as-is;
        /// otherwise it is resolved relative to <see cref="ProjectRootPath"/>.
        /// </summary>
        public static string SkillsRootFolderAbsolutePath
        {
            get
            {
                var folder = SkillsPath;
                return Path.IsPathRooted(folder)
                    ? folder
                    : Path.GetFullPath(Path.Combine(ProjectRootPath, folder));
            }
        }

        /// <summary>
        /// Resets the config file to its default state.
        /// </summary>
        public static void ResetConfig()
        {
            Instance.unityConnectionConfig.SetDefault();
            var plugin = CurrentPlugin;
            if (plugin != null)
                Instance.ApplyConfigToMcpPlugin(plugin);
            Instance.Save(captureCurrentToolStates: false);
        }

#if UNITY_EDITOR
        public static UnityEngine.TextAsset AssetFile => UnityEditor.AssetDatabase.LoadAssetAtPath<UnityEngine.TextAsset>(AssetsFilePath);
#endif

        UnityConnectionConfig GetOrCreateConfig() => GetOrCreateConfig(out _);
        UnityConnectionConfig GetOrCreateConfig(out bool wasCreated)
        {
            wasCreated = false;
            try
            {
                // Both Edit mode and Play mode read from the same UserSettings JSON file
                // Use the absolute path so File.Exists/ReadAllText resolve correctly regardless of CWD.
                var json = File.Exists(AssetsFileAbsolutePath) ? File.ReadAllText(AssetsFileAbsolutePath) : null;

                UnityConnectionConfig? config = null;
                try
                {
                    config = string.IsNullOrWhiteSpace(json)
                        ? null
                        : JsonSerializer.Deserialize<UnityConnectionConfig>(json!, new JsonSerializerOptions
                        {
                            PropertyNameCaseInsensitive = true,
                            Converters = { new JsonStringEnumConverter() }
                        });
                }
                catch (Exception e)
                {
                    _logger.LogCritical(e, "{method}: <color=red><b>{file}</b> file is corrupted at <i>{path}</i></color>",
                        nameof(GetOrCreateConfig), ResourcesFileName, AssetsFilePath);
                }
                if (config == null)
                {
                    _logger.LogWarning("{method}: <color=orange><b>Creating {file}</b> file at <i>{path}</i></color>",
                        nameof(GetOrCreateConfig), ResourcesFileName, AssetsFilePath);
                    config = new UnityConnectionConfig();
                    wasCreated = true;
                }

                // mcp-authorize g5/g6: migrate a persisted legacy `authorization=required` value to the
                // offline `token` mode BEFORE anything reads it. The b5 change deleted the server-side
                // `required` strategy, so launching the local server with it now crashes on boot. Re-save
                // (via wasCreated) so the healed value lands on disk.
                if (config.MigrateLegacyAuthOption())
                {
                    _logger.LogInformation(
                        "{method}: migrating AuthOption <i>required</i> -> <i>token</i> (legacy auth mode retired)",
                        nameof(GetOrCreateConfig));
                    wasCreated = true;
                }

                if (string.IsNullOrEmpty(config.LocalToken))
                {
                    config.LocalToken = GenerateToken();
                    wasCreated = true;
                }

                // Auto-heal a legacy absolute `SkillsPath` that points inside the project root.
                // Committing `UserSettings/AI-Game-Developer-Config.json` is supposed to be portable
                // across machines; a machine-specific absolute path breaks every other team member.
                // The normaliser also flips backslashes to forward slashes for cross-platform diff
                // stability. Absolute paths OUTSIDE the project root are intentional user choices
                // and are left untouched. Re-saving runs only when normalisation actually changed
                // the value, so a project with an already-relative SkillsPath does not get touched.
                if (!string.IsNullOrEmpty(config.SkillsPath))
                {
                    var normalizedSkills = NormalizeSkillsPath(config.SkillsPath);
                    if (!string.Equals(normalizedSkills, config.SkillsPath, StringComparison.Ordinal))
                    {
                        _logger.LogInformation(
                            "{method}: migrating SkillsPath from <i>{old}</i> to <i>{new}</i>",
                            nameof(GetOrCreateConfig), config.SkillsPath, normalizedSkills);
                        config.SkillsPath = normalizedSkills;
                        wasCreated = true;
                    }
                }

                return config;
            }
            catch (Exception e)
            {
                _logger.LogCritical(e, "{method}: <color=red><b>{file}</b> file can't be loaded from <i>{path}</i></color>",
                    nameof(GetOrCreateConfig), ResourcesFileName, AssetsFilePath);
                throw;
            }
        }

        public void Save(bool captureCurrentToolStates = true)
        {
#if UNITY_EDITOR
            Validate();
            try
            {
                var directory = Path.GetDirectoryName(AssetsFileAbsolutePath);
                if (!Directory.Exists(directory))
                    Directory.CreateDirectory(directory!);

                unityConnectionConfig ??= new UnityConnectionConfig();

                if (captureCurrentToolStates)
                {
                    var toolStates = Tools?.GetAllTools()
                        ?.Select(t => new UnityConnectionConfig.McpFeature(t.Name, Tools.IsToolVisible(t.Name)))
                        ?.ToList();

                    var promptStates = Prompts?.GetAllPrompts()
                        ?.Select(p => new UnityConnectionConfig.McpFeature(p.Name, Prompts.IsPromptEnabled(p.Name)))
                        ?.ToList();

                    var resourceStates = Resources?.GetAllResources()
                        ?.Select(r => new UnityConnectionConfig.McpFeature(r.Name, Resources.IsResourceEnabled(r.Name)))
                        ?.ToList();

                    unityConnectionConfig.Tools = toolStates != null && toolStates.Count > 0
                        ? toolStates
                        : UnityConnectionConfig.DefaultTools;

                    unityConnectionConfig.Prompts = promptStates != null && promptStates.Count > 0
                        ? promptStates
                        : UnityConnectionConfig.DefaultPrompts;

                    unityConnectionConfig.Resources = resourceStates != null && resourceStates.Count > 0
                        ? resourceStates
                        : UnityConnectionConfig.DefaultResources;
                }

                // Runtime-only overrides (env vars / CLI flags) MUST NOT be persisted to disk.
                // Temporarily restore the disk-baseline values for any overridden field, serialize,
                // then re-apply the overrides so the in-memory config keeps its runtime values.
                // The "in-memory keeps overrides" property is critical: callers (UI, configurators,
                // SignalR client) hold references to unityConnectionConfig and continue reading
                // from it after Save returns. Restoring overrides ensures behaviour is unchanged.
                var hasRuntimeOverrides = RuntimeOverrides != null && RuntimeOverrides.HasAny;
                if (hasRuntimeOverrides)
                    EnvironmentUtils.ApplyBaseline(unityConnectionConfig, RuntimeOverrides!);
                try
                {
                    var json = JsonSerializer.Serialize(unityConnectionConfig, new JsonSerializerOptions
                    {
                        WriteIndented = true,
                        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                        Converters = { new JsonStringEnumConverter() }
                    });
                    File.WriteAllText(AssetsFileAbsolutePath, json);
                }
                finally
                {
                    if (hasRuntimeOverrides)
                        EnvironmentUtils.ApplyOverrides(unityConnectionConfig, RuntimeOverrides!);
                }

                var assetFile = AssetFile;
                if (assetFile != null)
                    UnityEditor.EditorUtility.SetDirty(assetFile);
                else
                    UnityEditor.AssetDatabase.ImportAsset(AssetsFilePath);
            }
            catch (Exception e)
            {
                _logger.LogCritical(e, "{method}: <color=red><b>{file}</b> file can't be saved at <i>{path}</i></color>",
                    nameof(Save), ResourcesFileName, AssetsFilePath);
            }
#else
            // do nothing in runtime builds
            return;
#endif
        }
    }
}
